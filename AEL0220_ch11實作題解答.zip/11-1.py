for i in range( -4,5):
    for j in range(1,5-abs(i)+1):
        print(j,end='')
    print()
