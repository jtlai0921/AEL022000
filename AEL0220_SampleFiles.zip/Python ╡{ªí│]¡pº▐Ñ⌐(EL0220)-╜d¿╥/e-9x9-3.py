for i in range(1,10):
    for j in range (1,10):
        print ("%3d" %(i*j) , end='')
    print()
