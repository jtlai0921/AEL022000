for i in range(1,10):
    # print(i,end=' ')
    for j in range(1,10):
        if i*j <10 :
            print(' ',end='')
        print(i*j,end=' ' )
    print()
