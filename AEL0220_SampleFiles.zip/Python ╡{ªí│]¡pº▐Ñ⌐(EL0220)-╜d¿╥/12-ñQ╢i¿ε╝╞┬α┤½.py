# 十進制轉其他進制

dec = 168

print("十進制:",dec,":")
print("二進制=",str(bin(dec)))   # 0b 代表二進制
print("八進制=",str(oct(dec)))   # 0o 代表八進制
print("十六進制=",str(hex(dec))) # 0x 代表十六進制


    
