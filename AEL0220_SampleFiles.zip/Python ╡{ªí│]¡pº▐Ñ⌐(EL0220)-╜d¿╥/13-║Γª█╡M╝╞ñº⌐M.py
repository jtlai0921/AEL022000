# 算自然數之總和
num = 10
sum=0
while(num > 0):
    sum += num # 複合運算
    num -= 1   # 複合運算
print("總和=",sum)
