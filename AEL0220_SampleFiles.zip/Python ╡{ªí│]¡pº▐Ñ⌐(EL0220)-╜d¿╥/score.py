x=int(input('x=') )   # 使用者輸人
if x<0 :
    print('成績小於零')
elif  x>100 :        
    print('成績大於 100')
elif  x<60:
    print('成績不及格')
else:
    print('成績及格')

