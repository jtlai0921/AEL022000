a=65
b=92
print('阿珠的成績是:' +str(a)+' 阿花的成績是：'+str(b))
print('阿珠的成績是:%3d,阿花的成績是:%3d' %(a,b))
print('阿珠的成績是: {}, 阿花的成績是: {}'.format(str(a),str(b))) 
