#1050305-11

for  i in range(___+1):
    hold   =   a[i]
    a[i]     =   a[i+1]
    a[i+1] =   hold


