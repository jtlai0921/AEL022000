#1050305-21

for i in range(11):
    print("%d  "  %i)
    i = i + 1 
print("\n")





