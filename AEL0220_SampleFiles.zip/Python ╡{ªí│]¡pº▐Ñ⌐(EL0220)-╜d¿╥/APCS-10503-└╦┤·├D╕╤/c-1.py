#輸出如下圖 1050305-1
'''
    *
   ***
  *****
 *******
*********
'''


k=4
m=1
for i in range(1,6):
    for j in range(1,k+1):
        print(" ",end="")

    for j in range(1,m+1):
        print("*",end="")

    print("\n")
    k=k-1
    m=m+2
