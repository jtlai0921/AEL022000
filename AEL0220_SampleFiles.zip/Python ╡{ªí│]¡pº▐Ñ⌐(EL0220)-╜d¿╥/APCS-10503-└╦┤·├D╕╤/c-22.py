#1050305-22

def f():
    p=2
    while (p < 2000):
        p = 2*p       
    return p

#main
print("%d"  %f())



