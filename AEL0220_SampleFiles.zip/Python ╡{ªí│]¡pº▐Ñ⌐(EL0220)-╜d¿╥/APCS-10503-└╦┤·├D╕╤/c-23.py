#1050305-23

def f(n):
    p=0;  i=n
    while (i >=   (a)   ):
        p = 10 -   (b)   * i
        print("%d"  %p)
        i = i -   (c)


