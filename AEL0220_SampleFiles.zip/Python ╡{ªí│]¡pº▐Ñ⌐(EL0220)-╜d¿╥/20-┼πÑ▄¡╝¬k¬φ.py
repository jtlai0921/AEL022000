# 乘法表

for i in range(1, 10):
   for j in range( 1,10):
      print('%2dx%2d=%2d' %  (i,j,i*j), end=' ')  #%2d印出整數佔兩格
   print()  

