#  計算平方根
import math
n = 7
print('n  ** 0.5 =', n**0.5 )

r=  n**0.5
print('n  ** 0.5 = %0.5f' %r )

print( math.sqrt(9))
