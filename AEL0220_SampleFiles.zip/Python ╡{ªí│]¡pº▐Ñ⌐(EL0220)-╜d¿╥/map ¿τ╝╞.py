ipline='1 10 100 1000 10000 10000'
print(ipline)

list01=list(map(int,ipline.split()))
print(list01)
