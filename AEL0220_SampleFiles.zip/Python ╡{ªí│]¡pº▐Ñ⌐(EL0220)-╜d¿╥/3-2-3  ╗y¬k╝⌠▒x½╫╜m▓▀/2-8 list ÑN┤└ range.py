# (練習: 2-8)  
a=['Jerome', 0.38 , 1234 , True]
for i in a : 
    print(i)
