# (練習: 2-20)
greeting=['Red', 'Orange', 'Yellow', 'Green', 'Blue','White']
print(greeting[0:3])
print(greeting[2:4])
print(greeting[1])
