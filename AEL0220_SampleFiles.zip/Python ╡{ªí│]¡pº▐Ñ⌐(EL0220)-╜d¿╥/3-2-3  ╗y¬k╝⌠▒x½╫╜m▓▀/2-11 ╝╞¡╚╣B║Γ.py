# (練習: 2-11). 
# a=int(input('輸入整數1:  '))    # 提示輸入整數1
# b=int(input('輸入整數2:  '))    # 提示輸入整數 2
a=5
b=2 

print('a+b=',a+b) 
print('a-b=',a-b) 
print('a*b=',a*b) 
print('a/b=',a/b) 
print('a%b=',a%b)      # 餘數
print('a//b=',a//b)    # 商(整數)
print('a**b=',a**b)    # 次方

