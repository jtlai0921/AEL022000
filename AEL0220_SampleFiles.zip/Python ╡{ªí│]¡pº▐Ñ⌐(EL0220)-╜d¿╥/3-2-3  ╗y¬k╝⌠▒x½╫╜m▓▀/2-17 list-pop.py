# (練習: 2-17)
# 水果
fruits=['Apple','Banana','Watermelon','Mango']
print(fruits)
fruits.pop()     # 拿掉最後面一個
print(fruits)
