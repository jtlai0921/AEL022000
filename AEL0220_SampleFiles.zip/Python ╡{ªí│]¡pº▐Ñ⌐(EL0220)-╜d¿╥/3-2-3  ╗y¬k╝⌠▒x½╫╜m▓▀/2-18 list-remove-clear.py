# (練習: 2-18) 
fruits_dinner = [ '櫻桃','椰子','葡萄','芭樂', '檸檬']
fruits_dinner.remove('葡萄') 
print(fruits_dinner) 

fruits_dinner.clear() 
print(fruits_dinner) 
