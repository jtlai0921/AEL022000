age = 20               # 練習時這裡可分別輸入不同數字
if (age > 70) :
    print('老年')
elif (age < 30 ):
    print('青年')      
else:   #30-70
    print('壯年')
