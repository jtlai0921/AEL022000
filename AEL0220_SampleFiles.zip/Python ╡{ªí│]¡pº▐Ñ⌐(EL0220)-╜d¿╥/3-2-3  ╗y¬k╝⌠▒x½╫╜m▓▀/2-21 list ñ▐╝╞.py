# (練習: 2-21)
alpha=['A', 'B', 'C', 'D', 'E', 'F']
print(alpha[  :4])
print(alpha[3:  ])
