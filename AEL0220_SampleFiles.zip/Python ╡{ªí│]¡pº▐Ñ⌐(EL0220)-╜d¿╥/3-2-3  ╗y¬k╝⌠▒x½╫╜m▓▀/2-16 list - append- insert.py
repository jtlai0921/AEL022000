# (練習: 2-16)   
# 水果派對
fruits=['Apple','Banana','Watermelon','Mango']
fruits.append('Papaya')       # 增加 Papaya
print(fruits)

fruits.insert(2, 'Coconut')   # 增加 Coconut 在第三位
print(fruits)
