a = ['Jerome', 0.38, 1234, True]   # 設定串列
for i in range(0, len(a)):
    print(a[i])
print()

print(a[0])
print(a[1])
print(a[2])
print(a[3])
