# 海龍公式
a = 3 ; b = 6 ;c = 4

s = (a + b + c) / 2
area = (s*(s-a)*(s-b)*(s-c)) ** 0.5
print('面積 = %0.2f' % area)
