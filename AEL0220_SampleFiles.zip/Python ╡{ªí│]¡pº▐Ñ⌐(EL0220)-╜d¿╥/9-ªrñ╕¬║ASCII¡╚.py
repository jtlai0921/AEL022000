# 查特定字元的ASCII值

c = 'A'
print( c + " 的ASCII值=",ord(c))

c = 'a'
print( c + " 的ASCII值=",ord(c))

print(c + " 的ASCII值=", chr(65))

