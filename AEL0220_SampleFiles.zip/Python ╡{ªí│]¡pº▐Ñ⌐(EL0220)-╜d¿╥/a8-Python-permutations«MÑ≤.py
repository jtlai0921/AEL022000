# Python提供的 permutations 套件

from itertools import permutations 
perm = permutations([1, 2, 3,4]) 

for i in list(perm): 
    print(i) 
