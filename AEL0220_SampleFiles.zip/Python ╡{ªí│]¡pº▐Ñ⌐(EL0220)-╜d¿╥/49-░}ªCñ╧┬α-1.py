# 陣列反轉 (飆程式網 #1011) -1
# n=int(input())
# ipline= ()
n=5
ipline="2 3 12 4 5"
a = ipline.split(' ')
print(' '.join(reversed(a))) 
