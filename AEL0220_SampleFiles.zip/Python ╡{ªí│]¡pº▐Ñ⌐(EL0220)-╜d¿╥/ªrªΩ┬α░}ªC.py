# 字串轉陣列
# n=int(input()) 單筆資料取法
# ipline= ()     整行資料取法

ipline1="1 10 100 1000 10000"
newlist1 = ipline1.split(' ')
print(newlist1)

ipline2="A B C D E"
newlist2 = ipline2.split(' ')
print(newlist2)

