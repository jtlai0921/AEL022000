#！/usr/bin/python # -*- coding: UTF-8 -*- 
# 文件名：hello-python.py
# 第一個註解 寫在這裡
# 第二個註解 寫在這裡

print ( "Hello, Python！") 
