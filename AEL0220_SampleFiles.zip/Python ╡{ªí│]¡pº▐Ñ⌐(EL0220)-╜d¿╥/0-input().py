n=int(input('input 單筆數字 n:\n'))
list01=list(map(int,input('input 多筆數字 n:\n').split()))    
print(n)
print(list01,'\n')
