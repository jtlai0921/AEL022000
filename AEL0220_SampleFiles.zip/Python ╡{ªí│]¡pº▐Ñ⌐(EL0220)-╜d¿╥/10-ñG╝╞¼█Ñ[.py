#  計算兩數和
a=38
b=15

s= a+b
print(' a + b =', s)

