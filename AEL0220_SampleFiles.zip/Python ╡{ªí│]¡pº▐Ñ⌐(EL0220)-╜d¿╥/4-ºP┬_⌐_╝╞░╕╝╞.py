# 奇數還是偶數

n = int(input("輸入一個數:"))
if (n  % 2) == 0:
   print("{0} 是偶數".format(n))
else:
   print("{0} 是奇數".format(n))
