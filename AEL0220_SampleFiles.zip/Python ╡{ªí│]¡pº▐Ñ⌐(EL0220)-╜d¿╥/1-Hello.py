# This program prints Hello, Python 3!!

print('Hello, Python 3!')
