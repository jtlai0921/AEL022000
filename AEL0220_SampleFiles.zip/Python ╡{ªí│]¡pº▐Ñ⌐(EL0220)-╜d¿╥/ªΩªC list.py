list1=[2,4,6,8,10]
print(list1)

for i in range(5):
    print(list1[i],end=' ')
print()

for i in list1:
    print(i,end=' ')
