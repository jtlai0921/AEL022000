# 顯示月曆

# 載入套件
import calendar

# 輸入年
yy = 2019

# 輸入月
mm = 1

# 顯示月曆
print(calendar.month(yy, mm))

