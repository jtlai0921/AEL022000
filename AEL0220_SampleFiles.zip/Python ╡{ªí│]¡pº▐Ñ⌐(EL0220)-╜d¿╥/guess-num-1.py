c=0
guess=0
n=38
while (guess != n):
    guess=int(input('請輸入 (1~100)？'))
    c=c+1
    print( '你已經猜了:',c,'次')
