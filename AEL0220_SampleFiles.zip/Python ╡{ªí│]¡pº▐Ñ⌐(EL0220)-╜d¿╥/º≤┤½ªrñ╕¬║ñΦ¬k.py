# 在python中更換字元的方法，用前後字串相加而成
# 如果要換第三個字元 '3' 換成'A'
a='12345'
for i in range(0,5):
    print(i)

print(a[1:3])
b=a[0:2]+'A'+a[3:5]
print(b)




    
