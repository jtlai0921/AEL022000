# 檢查零、正 或 負數

num = float(input("輸入一個數: "))
if num > 0:
   print(num, "是正數")
elif num == 0:
   print("零")
else:
   print(num, "是負數")
