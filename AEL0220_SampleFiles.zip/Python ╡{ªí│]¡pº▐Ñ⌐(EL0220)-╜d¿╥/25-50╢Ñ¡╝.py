# 50階乘
fact=1
for n in range(1,51):
    fact = fact*n
    print("%2d!= %d" %(n,fact)) 
