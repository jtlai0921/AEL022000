
def sum(n):
    s=0
    for i in range(n+1):
        s=s+i
    return s

print(sum(100))
