# 陣列反轉 (飆程式網 #1011) -2
n=5
ipline="2 3 12 4 5"
a = map(int, ipline.split(' '))
print(' '.join(map(str, reversed(list(a)))))

# 上傳飆程式網 #1011 的程式 (僅上傳下面三行 )
'''
n = input()
a = map(int, input().split(' '))
print(' '.join(map(str, reversed(list(a)))))
'''
