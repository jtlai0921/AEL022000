for num in range(2, 10):
    if num % 2 == 0:
        print(num,"是偶數")
        continue
    print(num , "...是奇數")
